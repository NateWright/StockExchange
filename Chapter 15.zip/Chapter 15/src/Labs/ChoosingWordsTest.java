package Labs;

public class ChoosingWordsTest {

	public static void main(String args[]) {
		ChoosingWords.choosingWords();
	}
}
