package Labs;

import java.io.*;
import java.util.Scanner;

public class ChoosingWords {

	public static void choosingWords() {
		
		//Starts File reader
		String inputName = "words.txt";
		File file = new File(inputName);
		Scanner input = null;
		
		try {
			input = new Scanner(file);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot open " + inputName + " ***");
			System.exit(1);
		}
		
		//Starts file writer
		String outputName = "output.java";
		Writer writer = null;
		try {
			writer = new FileWriter(outputName, true);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot create/open " + outputName + " ***");
			System.exit(1);
		}
		PrintWriter output = new PrintWriter(writer);
		
		//Prints output
		output.println("public class RamblecsDictionary");
		output.println("{");
		output.println("\tprivate String[] words = ");
		output.println("\t{");
		while(input.hasNextLine()) {
			String str = input.nextLine();
			str = str.toUpperCase();
			if(str.length() == 3 || str.length() == 4 || str.length() == 5)
				output.println("\t\t\""+str+"\",");
		}
		output.println("\t};");
		output.println("}");
		output.close();
		input.close();
	}
}
