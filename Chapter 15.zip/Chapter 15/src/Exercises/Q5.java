package Exercises;

import java.io.File;
import java.util.Scanner;

public class Q5 {

	public static String data(String pathName) {
		File file = new File(pathName);
		Scanner input = null;
		
		try {
			input = new Scanner(file);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot open " + pathName + " ***");
			System.exit(1);
		}
		String str = "";
		while(input.hasNextLine()) {
			str = str + input.nextLine();
		}
		input.close();
		return str;
	}
	
	public static boolean matchingData(String path1, String path2) {
		if(data(path1).contentEquals(data(path2)))
			return true;
		else
			return false;
		
	}
	
}
