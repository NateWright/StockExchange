package Exercises;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class madLibs {
	
	private ArrayList<String> List;
	private  ArrayList<String> newList;
	private Scanner kb;
	
	public madLibs() {
		List = new ArrayList<String>(0);
		newList = new ArrayList<String>(0);
	}
	
	public void doMadLibs() {
		kb = new Scanner(System.in);
		System.out.println("Enter file name:");
		String pathName = kb.next();
		find(pathName);
		//System.out.println(List);
		ask();
		//System.out.println(newList);
		File file = new File(pathName);
		Scanner input = null;
		
		try {
			input = new Scanner(file);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot open " + pathName + " ***");
			System.exit(1);
		}
		int x = 0;
		while(input.hasNextLine()) {
			String str = input.nextLine();
			if(x<List.size()-1) {
				while(str.contains(List.get(x))) {
					//System.out.println(List.get(x)+" "+newList.get(x)+" "+ x);
					str = str.replaceFirst(List.get(x), newList.get(x));
					x++;
				}
			}
			System.out.println(str);
		}
		kb.close();
	}
	
	public void find(String pathName) {
		File file = new File(pathName);
		Scanner input = null;
		
		try {
			input = new Scanner(file);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot open " + pathName + " ***");
			System.exit(1);
		}
		int posL = 0, posR = 0;
		while(input.hasNext()) {
			String Line = input.next();
			for(int x = 0; x<Line.length(); x++) {
				if(Line.charAt(x)=='<') {
					posL = x;
					while(Line.charAt(x)!='>')
						x++;
					posR = x;
				}
			}
			if(posR != 0) 
				List.add(Line.substring(posL,posR+1));
			posL = 0;
			posR = 0;
		}
		
		input.close();
	}
	public void ask() {
		
		for(int x = 0; x < List.size(); x++) {
			String word = List.get(x);
			System.out.println("Please give me an/a:"+word.substring(1,word.length()-1));
			word = kb.next();
			newList.add(word);
		}
	}
}
