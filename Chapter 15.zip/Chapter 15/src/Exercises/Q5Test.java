package Exercises;

public class Q5Test {

	public static void main(String args[]) {
		System.out.print(Q5.matchingData("QuadraticFunction.java", "QuadraticFunction2.java"));
	}
}
