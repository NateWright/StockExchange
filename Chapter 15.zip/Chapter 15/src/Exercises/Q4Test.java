package Exercises;

public class Q4Test {
	
	public static void main(String args[]) {
		System.out.print(Q4.braceCheck());
	}
}
