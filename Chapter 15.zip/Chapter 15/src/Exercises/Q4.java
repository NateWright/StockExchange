package Exercises;

import java.io.File;
import java.util.Scanner;

public class Q4 {
	
	public static boolean braceCheck() {
		int openCount = 0;
		int closedCount = 0;
		
		String pathName = "QuadraticFunction.java";
		File file = new File(pathName);
		Scanner input = null;
		
		try {
			input = new Scanner(file);
		}
		catch(Exception ex) {
			System.out.println("*** Cannot open " + pathName + " ***");
			System.exit(1);
		}
		
		while(input.hasNextLine()) {
			String str = input.nextLine();
			for(int x = 0; x < str.length(); x++) {
				char c = str.charAt(x);
				
				if(c == '{')
					openCount++;
				else if(c == '}')
					closedCount++;
			}
		}
		
		input.close();
		
		if(openCount == closedCount)
			return true;
		else 
			return false;
	}
}
