package Exercises;

public class Q10Test {
	
	public static void main(String args[]) {
		madLibs ml = new madLibs();
		ml.doMadLibs();
		//madLibs.find("madlibs.txt");
		//madLibs.ask();
	}
}
