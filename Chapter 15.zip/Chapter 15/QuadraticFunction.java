package Exercises;

public class QuadraticFunction {
	private int a, b, c;
	
	public QuadraticFunction(int a, int b, int c){
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	public double valueAt(double x) {
		return a*x*x+b*x+c;
	}
	public String toString() {
		String output = a + "x^2";
		if(b>0) {
			output = output +"+"+ b + "x";
			
			if(c>0) {
				output = output +"+"+ c;
			}
			else {
				output = output + c;
			}
		}
		else {
			output = output + b + "x";
			
			if(c>0) {
				output = output +"+"+ c;
			}
			else {
				output = output + c;
			}
		}
		return output;
	}
	
	public boolean equals(QuadraticFunction q2) {
		if(a == q2.a && b == q2.b && c == q2.c) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int compareTo(QuadraticFunction q2) {
		if(a>q2.a) {
			return 1;
		}
		else if(a<q2.a) {
			return -1;
		}
		else {
			if(b>q2.b) {
				return 1;
			}
			else if(b<q2.b) {
				return -1;
			}
			else {
				if(c>q2.c) {
					return 1;
				}
				else if(c<q2.c) {
					return -1;
				}
				else {
					return 0;
				}
			}
		}
	}
	
}
