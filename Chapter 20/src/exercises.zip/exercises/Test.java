package exercises;

import java.util.Stack;

public class Test {

	public static void main(String args[]) {
		
		
	}
}
